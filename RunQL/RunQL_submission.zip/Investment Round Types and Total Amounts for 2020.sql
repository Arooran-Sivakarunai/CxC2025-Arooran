SELECT
  roundType,
  SUM(amount) AS total_amount
FROM
  deals
WHERE
  year = '2020'
GROUP BY
  roundType;