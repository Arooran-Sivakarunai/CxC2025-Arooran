SELECT
  yearQuarter,
  COUNT(*) as enormous_investments
FROM
  deals
WHERE
  amount >= 100000000
GROUP BY
  yearQuarter;