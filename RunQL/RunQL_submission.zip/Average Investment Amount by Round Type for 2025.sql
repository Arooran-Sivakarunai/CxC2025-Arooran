SELECT
  roundType,
  AVG(amount) AS average_amount
FROM
  deals
WHERE
  year = '2025'
GROUP BY
  roundType;