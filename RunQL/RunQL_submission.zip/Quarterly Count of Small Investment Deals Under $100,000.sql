SELECT
  yearQuarter,
  COUNT(*) as minute_investments
FROM
  deals
WHERE
  amount <= 100000
GROUP BY
  yearQuarter;