SELECT
  di.roundType AS investmentStage,
  AVG(de.amount) AS averageDealSize
FROM
  dealInvestor di
  JOIN deals de ON di.dealId = de.id
  JOIN investors i ON di.investorId = i.id
WHERE
  di.investorCountry = 'USA'
GROUP BY
  di.roundType,
  di.investorCountry;