SELECT
  yearQuarter,
  SUM(amount) AS total_amount
FROM
  deals
GROUP BY
  yearQuarter;