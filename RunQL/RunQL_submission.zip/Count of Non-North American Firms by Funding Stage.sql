SELECT
  i.stages AS FundingStage,
  COUNT(DISTINCT i.id) AS NumberOfFirms
FROM
  investors i
WHERE
  i.country NOT IN ('Canada', 'USA')
GROUP BY
  i.stages;