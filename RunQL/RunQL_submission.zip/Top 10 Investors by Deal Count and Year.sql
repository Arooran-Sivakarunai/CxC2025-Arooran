SELECT
  di.investorName,
  di.year,
  COUNT(di.dealId) AS deal_count
FROM
  dealInvestor di
GROUP BY
  di.investorName,
  di.year
ORDER BY
  deal_count DESC,
  di.year DESC
LIMIT
  10;