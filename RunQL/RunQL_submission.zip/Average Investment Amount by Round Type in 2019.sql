SELECT
  roundType,
  AVG(amount) AS average_amount
FROM
  deals
WHERE
  year = '2019'
GROUP BY
  roundType;