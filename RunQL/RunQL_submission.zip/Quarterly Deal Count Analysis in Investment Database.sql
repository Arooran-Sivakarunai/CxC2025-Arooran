SELECT
  yearQuarter,
  COUNT(amount) AS total_count
FROM
  deals
GROUP BY
  yearQuarter;