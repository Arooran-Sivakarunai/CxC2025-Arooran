SELECT
  c.primaryTag AS primary_tag,
  SUM(d.amount) AS total_amount_spent
FROM
  deals d
  JOIN dealInvestor di ON d.id = di.dealId
  JOIN investors i ON di.investorId = i.id
  JOIN companies c ON d.companyId = c.id
WHERE
  i.country = 'USA'
GROUP BY
  c.primaryTag;