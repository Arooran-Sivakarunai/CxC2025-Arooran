SELECT
  roundType,
  COUNT(*) AS round_count
FROM
  deals
WHERE
  year = '2023'
GROUP BY
  roundType;