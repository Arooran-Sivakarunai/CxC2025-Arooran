SELECT
  roundType,
  SUM(amount) AS total_amount
FROM
  deals
WHERE
  year = '2023'
GROUP BY
  roundType;