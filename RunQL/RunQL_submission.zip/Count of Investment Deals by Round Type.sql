SELECT
  roundType,
  COUNT(*) AS round_count
FROM
  deals
GROUP BY
  roundType;