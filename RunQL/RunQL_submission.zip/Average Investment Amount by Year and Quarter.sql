SELECT
  yearQuarter,
  AVG(amount) AS total_amount
FROM
  deals
GROUP BY
  yearQuarter;