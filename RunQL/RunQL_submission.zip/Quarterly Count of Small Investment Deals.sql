SELECT
  yearQuarter,
  COUNT(*) as small_investments
FROM
  deals
WHERE
  amount > 100000
  AND amount <= 1000000
GROUP BY
  yearQuarter;