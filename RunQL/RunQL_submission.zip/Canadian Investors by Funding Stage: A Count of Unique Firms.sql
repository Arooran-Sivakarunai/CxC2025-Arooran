SELECT
  i.stages AS FundingStage,
  COUNT(DISTINCT i.id) AS NumberOfFirms
FROM
  investors i
WHERE
  i.country = 'Canada'
GROUP BY
  i.stages;