SELECT
  d.year AS year,
  SUM(d.amount) AS total_amount_spent
FROM
  deals d
  JOIN dealInvestor di ON d.id = di.dealId
  JOIN investors i ON di.investorId = i.id
WHERE
  i.country = 'USA'
GROUP BY
  d.year
ORDER BY
  year;