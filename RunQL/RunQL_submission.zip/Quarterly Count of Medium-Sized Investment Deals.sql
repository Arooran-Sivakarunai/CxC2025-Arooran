SELECT
  yearQuarter,
  COUNT(*) as medium_investments
FROM
  deals
WHERE
  amount > 1000000
  AND amount <= 10000000
GROUP BY
  yearQuarter;