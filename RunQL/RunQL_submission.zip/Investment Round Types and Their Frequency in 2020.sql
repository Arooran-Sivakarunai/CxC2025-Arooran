SELECT
  roundType,
  COUNT(*) AS round_count
FROM
  deals
WHERE
  year = '2020'
GROUP BY
  roundType;