SELECT
  yearQuarter,
  COUNT(*) as large_investments
FROM
  deals
WHERE
  amount > 10000000
  AND amount <= 25000000
GROUP BY
  yearQuarter;