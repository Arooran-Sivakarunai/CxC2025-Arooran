SELECT
  roundType,
  AVG(amount) AS average_amount
FROM
  deals
WHERE
  year = '2024'
GROUP BY
  roundType;