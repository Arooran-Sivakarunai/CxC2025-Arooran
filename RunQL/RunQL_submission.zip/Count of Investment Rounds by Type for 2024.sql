SELECT
  roundType,
  COUNT(*) AS round_count
FROM
  deals
WHERE
  year = '2024'
GROUP BY
  roundType;