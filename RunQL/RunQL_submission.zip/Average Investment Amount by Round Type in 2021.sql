SELECT
  roundType,
  AVG(amount) AS average_amount
FROM
  deals
WHERE
  year = '2021'
GROUP BY
  roundType;