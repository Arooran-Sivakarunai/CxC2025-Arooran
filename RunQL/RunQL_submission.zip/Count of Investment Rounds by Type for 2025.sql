SELECT
  roundType,
  COUNT(*) AS round_count
FROM
  deals
WHERE
  year = '2025'
GROUP BY
  roundType;